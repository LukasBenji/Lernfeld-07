from boolquestion import BoolQuestion
from colorama import Fore
from mc import multiple_choice



class PythonTrainer:
    """Overall class to manage game assets and behavior."""
    def __init__(self, questions):
        """Initialize the game, and create game resources."""
        self.__state = 0
        self.__questions = questions

    def run_main(self):
        """Run main loop of the game."""
        while True:
            if self.__state == 0:  # menu
                input("Press Return to Start\n")
                self.__state = 1
            elif self.__state == 1:  # questions
                for q in self.__questions:
                    q.question_loop()
                self.__state = 2
            else:  # round finished -> draw results
                self.print_results()
                self.__state = 0

    def print_results(self):
        print("\nERGEBNISSE!\n")
        print(f"{'Frage': <8}{'Lösung': <10}{'Antwort': <10}{'Punkte': <8}")
        sum_points = 0
        for i, bc in enumerate(self.__questions):
            points = bc.calc_player_points()
            sum_points += points
            line = f"{i + 1: >2}{':': <6}{bc.get_correct_choice(): <10}{bc.get_player_choice(): <10}{points: <8}"
            if bc.get_correct_choice() == bc.get_player_choice():
                print(Fore.GREEN+line)
            else:
                print(Fore.RED+line)

        print(Fore.WHITE+f"{'_' * 36}")
        print(f"{'Summe Punkte:': <28}{sum_points}\n")


if __name__ == '__main__':

    wahl = ""

    while True:
        eingabe = input("Möchtest du ein Thema auswählen? (J/N):")
        if eingabe in ["N", "n"]:
            wahl = "n"
            break
        if eingabe in ["J", "j"]:
            abfrage = input(
                "Gebe das gewünschte Thema an, schreibe adfür den Anfangsbuchstabe in die console und drücke enter"
                "Die Themenwahl besteht aus:\n Boolquestion:\n Multiplechoicequestion: \n")
            if abfrage in ["B", "b"]:
                wahl = "b"
                break
            elif abfrage in ["M", "m"]:
                wahl = "m"
                break


    list =[]
    if wahl in ["B","b","M","m","N","n"]:
        if wahl in ["N", "n"]:
            BC_1 = BoolQuestion("BC1", 3, ["3 < 4 or False"], 1)
            BC_2 = BoolQuestion("BC2", 3, ["not(not False)"], 0)
            BC_3 = BoolQuestion("BC3", 3, ["8 % 4"], 0)

            MC_1 = multiple_choice("MC1", 3, ["Was ist die Hauptstadt von Frankreich?"], 0)

            list = [BC_1, BC_2, BC_3, MC_1]


        if wahl in ["B","b"]:
            BC_1 = BoolQuestion("BC1", 3, ["3 < 4 or False"], 1)
            BC_2 = BoolQuestion("BC2", 3, ["not(not False)"], 0)
            BC_3 = BoolQuestion("BC3", 3, ["8 % 4"], 0)

            list = [BC_1, BC_2, BC_3]


        elif wahl in ["M","m"]:
            MC_1 = multiple_choice("MC1", 3, ["Was ist die Hauptstadt von Frankreich?"], 0)

            list = [MC_1]

    else:
        print("invalide Eingabe")
    # Make a game instance, and run the game.
    pt = PythonTrainer(list)
    pt.run_main()
