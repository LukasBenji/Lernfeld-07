from typing import List
from colorama import Fore


class BoolQuestion:
    def __init__(self, name, points, lines: List, correct_answer):
        self.__name = name
        self.__points = points
        self.__lines = lines
        self.__choices = ["False", "True"]
        self.__correct_answer = correct_answer
        self.__player_answer = -1

    def reset_player_answer(self):
        self.__player_answer = -1

    def get_choices(self) -> List:
        return self.__choices

    def get_player_answer(self):
        return self.__player_answer

    def get_player_choice(self):
        return self.__choices[self.__player_answer]

    def get_correct_choice(self):
        return self.__choices[self.__correct_answer]

    def get_points(self):
        return self.__points

    def calc_player_points(self):
        return self.get_points() if self.__player_answer == self.__correct_answer else 0

    def question_loop(self):
        self.reset_player_answer()
        possible_answers = ["0", "1"]
        while True:
            self.print_question()
            self.print_choices()
            if self.__player_answer == -1:
                answer = input(Fore.BLACK + "Tippe die Nummer und dann Return zur Auswahl. ")
                if answer in possible_answers:
                    self.__player_answer = int(answer)
                else:
                    print("Es wurde keine mögliche Antwort ausgewählt!")
            else:
                answer = input(Fore.BLACK + "Bestätige mit Return oder tippe andere Nummer. ")
                if answer in possible_answers:
                    self.__player_answer = int(answer)
                elif answer == "":
                    break
                else:
                    print("Die Auswahl war nicht korrekt!")
            print()

    def print_question(self):
        print(f"\n{self.__name}")
        print("Frage: Welchen Wert ergibt die Bedingung?")
        for i, line in enumerate(self.__lines):
            print(Fore.CYAN+"  " + line)

    def print_choices(self):
        print(Fore.BLACK+"Mögliche Antworten!")
        for i, choice in enumerate(self.get_choices()):
            if self.__player_answer == i:
                print(Fore.GREEN+f"  {i}: {choice}")
            else:
                print(Fore.LIGHTBLACK_EX+f"  {i}: {choice}")
